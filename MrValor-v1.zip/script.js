const menuButton = document.getElementById('menuButton');
const mobileMenu = document.getElementById('mobileMenu');
const searchToggle = document.getElementById('searchToggle');
const searchPanel = document.getElementById('searchPanel');
const searchClose = document.getElementById('searchClose');
const searchInput = document.getElementById('searchInput');
const productCards = [...document.querySelectorAll('.product-card')];
const cartCount = document.getElementById('cartCount');
const toast = document.getElementById('toast');
let cart = [];

menuButton?.addEventListener('click', () => {
  mobileMenu.style.display = mobileMenu.style.display === 'block' ? 'none' : 'block';
});

mobileMenu?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
  mobileMenu.style.display = 'none';
}));

searchToggle?.addEventListener('click', () => {
  searchPanel.style.display = 'block';
  searchInput.focus();
});
searchClose?.addEventListener('click', () => searchPanel.style.display = 'none');

function filterProducts(query=''){
  const q = query.trim().toLowerCase();
  productCards.forEach(card => {
    const text = `${card.dataset.name} ${card.dataset.category} ${card.innerText}`.toLowerCase();
    card.style.display = !q || text.includes(q) ? '' : 'none';
  });
}
searchInput?.addEventListener('input', e => filterProducts(e.target.value));

document.querySelectorAll('.category-card').forEach(btn => {
  btn.addEventListener('click', () => {
    const category = btn.dataset.filter.toLowerCase();
    productCards.forEach(card => {
      card.style.display = card.dataset.category.toLowerCase() === category ? '' : 'none';
    });
    document.getElementById('featured').scrollIntoView({behavior:'smooth'});
  });
});

document.getElementById('showAll')?.addEventListener('click', () => {
  productCards.forEach(card => card.style.display = '');
  document.getElementById('featured').scrollIntoView({behavior:'smooth'});
});

document.querySelectorAll('.add-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    cart.push({name:btn.dataset.product, price:Number(btn.dataset.price)});
    cartCount.textContent = cart.length;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 1800);
  });
});

document.getElementById('cartButton')?.addEventListener('click', () => {
  if (!cart.length) {
    alert('السلة فارغة حاليًا. أضف منتجًا أولًا.');
    return;
  }
  const total = cart.reduce((sum,item) => sum + item.price, 0);
  alert(`عدد المنتجات: ${cart.length}\nالإجمالي: $${total.toFixed(2)}\n\nهذه نسخة الواجهة الأولى؛ سنربط السلة والدفع والتنزيلات لاحقًا.`);
});

document.getElementById('newsletterForm')?.addEventListener('submit', e => {
  e.preventDefault();
  alert('تم تسجيل طلب الاشتراك في النسخة التجريبية. سنربط البريد لاحقًا.');
  e.target.reset();
});
